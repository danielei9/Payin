"use strict";

window.smartband = {
    'echo' : function(message, win, fail) {
        cordova.exec(win, fail, "smartband", "echo", [message]);
    }
}
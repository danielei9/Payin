package com.payin.palago.smartband;

import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CallbackContext;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class smartband extends CordovaPlugin {
    @Override
    public void initialize(CordovaInterface cordova, CordovaWebView webView) {
    	super.initialize(cordova, webView);
    }

    @Override
    public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
        if(action.equals("echo")){
            String message = args.getString(0); 
            callbackContext.success(message);
            return true;
        }
        callbackContext.success(action);
        return true;
    }

    @Override
    public void onPause(boolean multitasking) {
        Log.d(TAG, "onPause()");
        super.onPause(multitasking);
    }

    @Override
    public void onResume(boolean multitasking) {
        Log.d(TAG, "onResume()");
        super.onResume(multitasking);
    }
}